<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style lang="scss">
  @import './styles/common';
  // #nprogress .bar {
  //     background: red !important; //自定义颜色
  //   }
</style>
