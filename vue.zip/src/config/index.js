export default {
  // 所有的配置
}