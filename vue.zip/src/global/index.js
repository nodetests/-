import Vue from 'vue'
Vue.component()